<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'wsHjcgSSPHYi53iz6dxxBDUG3dAELIGj0G7ueG04u4G4o6rUannV0EyRvDJpEpqs');
define('SECURE_AUTH_KEY',  'ALWxiEizNPeGAUr65ysxphbKUSeK6DuTrXmDzeKEvfKYmehgBbcBm34Y9oaGwmuU');
define('LOGGED_IN_KEY',    'CjWp1WPonxgXPj0nKSweJSC55zRfvC6y1uqGhfUg48j57do2zVVNYAnFcXfduJIu');
define('NONCE_KEY',        'I51pbESYKhi78E7rRc0Bdbhff5WgGKuRwqRveD9eshX5aM7XvjYb1iNTcuhmttr7');
define('AUTH_SALT',        'q5IpqrcrfvEpdDumKS3WfBE0EXTeFuXhuuiWchepttAj48VTrNxQx3g0hqqRqACh');
define('SECURE_AUTH_SALT', '2XmFhDvodinmBDTdXE9FzeJPINUbF9gVUJKxbITGuy56yEJ59tKWSL5puXJopQRJ');
define('LOGGED_IN_SALT',   'xeq5fi8MJmeWVMLKaozN32rim8qDP1vztrhi0cmUdxeoi7iX1eJeaCUCmr4tQGjJ');
define('NONCE_SALT',       'X0dy8BIt8oUjpMT7M4GCs3B5amN581Bnyr6uqIuoCMPG2bFzWz7W3KXyJ4a85CEb');
